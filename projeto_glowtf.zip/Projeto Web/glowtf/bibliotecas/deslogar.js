function deslogar(){
    window.location.href = '../login/login.html';
}

document.addEventListener("DOMContentLoaded", () => deslogar());