<?php
    $host = "localhost";
    $port = "3307";
    $usuario = "root";
    $senha = "";
    $banco = "glowtfdb";
    $conn = new mysqli($host, $usuario, $senha, $banco, $port);
?>