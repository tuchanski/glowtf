//Redireciona para a home de verdade
function redirect(){
    MoverPagina("../../home/home.html");
}

document.addEventListener("DOMContentLoaded", () => redirect());